//open source esk8 brake light controller by Mich21050//
//config.h


#define threshold xxxx            //insert your number here//
#define num_front x               //number of leds in the front//
#define num_back x                //number of leds in the back//
#define threshold_ch3 xxxx        //insert ch3 trigger value here//
